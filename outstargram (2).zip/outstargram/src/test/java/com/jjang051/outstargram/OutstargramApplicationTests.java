package com.jjang051.outstargram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OutstargramApplicationTests {

	@Test
	void contextLoads() {
	}

}
