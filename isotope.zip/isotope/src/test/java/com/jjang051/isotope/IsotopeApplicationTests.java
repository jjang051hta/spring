package com.jjang051.isotope;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IsotopeApplicationTests {

	@Test
	void contextLoads() {
	}

}
